import { db } from "./db";
import { gameCategories, games, gameQuestions, achievements } from "@shared/schema";

const categories = [
  {
    name: "Mathematics",
    slug: "mathematics",
    description: "Mathematical problems and calculations",
    icon: "calculator",
    color: "#3b82f6",
  },
  {
    name: "Science",
    slug: "science",
    description: "Physics, chemistry, biology, and more",
    icon: "flask",
    color: "#10b981",
  },
  {
    name: "Languages",
    slug: "languages",
    description: "Language learning and comprehension",
    icon: "book",
    color: "#8b5cf6",
  },
  {
    name: "Business",
    slug: "business",
    description: "Business concepts and entrepreneurship",
    icon: "briefcase",
    color: "#f59e0b",
  },
  {
    name: "Physics",
    slug: "physics",
    description: "Laws of physics and natural phenomena",
    icon: "atom",
    color: "#ef4444",
  },
  {
    name: "Entertainment",
    slug: "entertainment",
    description: "Fun trivia and entertainment questions",
    icon: "gamepad",
    color: "#ec4899",
  },
  {
    name: "Computer Science",
    slug: "computer-science",
    description: "Programming, algorithms, and technology",
    icon: "monitor",
    color: "#6366f1",
  },
  {
    name: "General Knowledge",
    slug: "general-knowledge",
    description: "Wide range of general knowledge topics",
    icon: "brain",
    color: "#eab308",
  },
];

const sampleGames = [
  {
    title: "Basic Arithmetic Challenge",
    slug: "basic-arithmetic-challenge",
    description: "Test your skills with addition, subtraction, multiplication, and division",
    categoryId: 1, // Mathematics
    difficulty: "beginner",
    gameType: "math",
    minAge: 8,
    estimatedDuration: 15,
    isActive: true,
  },
  {
    title: "Advanced Calculus Quiz",
    slug: "advanced-calculus-quiz",
    description: "Challenge yourself with derivatives, integrals, and limits",
    categoryId: 1, // Mathematics
    difficulty: "advanced",
    gameType: "math",
    minAge: 16,
    estimatedDuration: 30,
    isActive: true,
  },
  {
    title: "Chemistry Fundamentals",
    slug: "chemistry-fundamentals",
    description: "Explore the basics of atoms, molecules, and chemical reactions",
    categoryId: 2, // Science
    difficulty: "intermediate",
    gameType: "science",
    minAge: 12,
    estimatedDuration: 20,
    isActive: true,
  },
  {
    title: "Biology Masterclass",
    slug: "biology-masterclass",
    description: "Dive into the fascinating world of living organisms",
    categoryId: 2, // Science
    difficulty: "advanced",
    gameType: "science",
    minAge: 14,
    estimatedDuration: 25,
    isActive: true,
  },
  {
    title: "English Vocabulary Builder",
    slug: "english-vocabulary-builder",
    description: "Expand your English vocabulary with challenging words",
    categoryId: 3, // Languages
    difficulty: "intermediate",
    gameType: "language",
    minAge: 10,
    estimatedDuration: 15,
    isActive: true,
  },
  {
    title: "Spanish Conversation Practice",
    slug: "spanish-conversation-practice",
    description: "Practice Spanish phrases and grammar",
    categoryId: 3, // Languages
    difficulty: "beginner",
    gameType: "language",
    minAge: 12,
    estimatedDuration: 20,
    isActive: true,
  },
  {
    title: "Entrepreneurship Basics",
    slug: "entrepreneurship-basics",
    description: "Learn the fundamentals of starting and running a business",
    categoryId: 4, // Business
    difficulty: "beginner",
    gameType: "quiz",
    minAge: 16,
    estimatedDuration: 25,
    isActive: true,
  },
  {
    title: "Physics Laws & Principles",
    slug: "physics-laws-principles",
    description: "Understand the fundamental laws that govern our universe",
    categoryId: 5, // Physics
    difficulty: "intermediate",
    gameType: "science",
    minAge: 14,
    estimatedDuration: 20,
    isActive: true,
  },
  {
    title: "World Trivia Challenge",
    slug: "world-trivia-challenge",
    description: "Test your knowledge about world geography, history, and culture",
    categoryId: 6, // Entertainment
    difficulty: "intermediate",
    gameType: "quiz",
    minAge: 10,
    estimatedDuration: 15,
    isActive: true,
  },
  {
    title: "Programming Fundamentals",
    slug: "programming-fundamentals",
    description: "Learn basic programming concepts and logic",
    categoryId: 7, // Computer Science
    difficulty: "beginner",
    gameType: "quiz",
    minAge: 12,
    estimatedDuration: 30,
    isActive: true,
  },
];

const sampleQuestions = [
  // Math questions
  {
    gameId: 1,
    question: "What is 12 + 8?",
    options: JSON.stringify(["18", "20", "22", "24"]),
    correctAnswer: "20",
    explanation: "12 + 8 = 20",
    difficulty: "beginner",
    points: 10,
  },
  {
    gameId: 1,
    question: "What is 15 × 4?",
    options: JSON.stringify(["56", "60", "64", "68"]),
    correctAnswer: "60",
    explanation: "15 × 4 = 60",
    difficulty: "beginner",
    points: 10,
  },
  {
    gameId: 2,
    question: "What is the derivative of x²?",
    options: JSON.stringify(["x", "2x", "x²", "2x²"]),
    correctAnswer: "2x",
    explanation: "The derivative of x² is 2x using the power rule",
    difficulty: "advanced",
    points: 20,
  },
  // Science questions
  {
    gameId: 3,
    question: "What is the chemical symbol for gold?",
    options: JSON.stringify(["Go", "Au", "Ag", "Gd"]),
    correctAnswer: "Au",
    explanation: "Au comes from the Latin word aurum, meaning gold",
    difficulty: "intermediate",
    points: 15,
  },
  {
    gameId: 4,
    question: "What is the powerhouse of the cell?",
    options: JSON.stringify(["Nucleus", "Mitochondria", "Ribosome", "Golgi apparatus"]),
    correctAnswer: "Mitochondria",
    explanation: "Mitochondria produce energy (ATP) for the cell",
    difficulty: "intermediate",
    points: 15,
  },
  // Language questions
  {
    gameId: 5,
    question: "What does 'ubiquitous' mean?",
    options: JSON.stringify(["Rare", "Everywhere", "Beautiful", "Ancient"]),
    correctAnswer: "Everywhere",
    explanation: "Ubiquitous means present, appearing, or found everywhere",
    difficulty: "intermediate",
    points: 12,
  },
  {
    gameId: 6,
    question: "How do you say 'Hello' in Spanish?",
    options: JSON.stringify(["Bonjour", "Hola", "Ciao", "Guten Tag"]),
    correctAnswer: "Hola",
    explanation: "Hola is the Spanish greeting for hello",
    difficulty: "beginner",
    points: 10,
  },
  // Trivia questions
  {
    gameId: 9,
    question: "What is the capital of Australia?",
    options: JSON.stringify(["Sydney", "Melbourne", "Canberra", "Perth"]),
    correctAnswer: "Canberra",
    explanation: "Canberra is the capital city of Australia",
    difficulty: "intermediate",
    points: 12,
  },
];

const sampleAchievements = [
  {
    title: "First Steps",
    description: "Complete your first game",
    icon: "trophy",
    points: 10,
    condition: JSON.stringify({ type: "games_completed", value: 1 }),
    isActive: true,
  },
  {
    title: "Scholar",
    description: "Complete 10 games",
    icon: "star",
    points: 50,
    condition: JSON.stringify({ type: "games_completed", value: 10 }),
    isActive: true,
  },
  {
    title: "Perfect Score",
    description: "Get 100% correct answers in a game",
    icon: "target",
    points: 25,
    condition: JSON.stringify({ type: "perfect_score", value: 1 }),
    isActive: true,
  },
  {
    title: "Speed Demon",
    description: "Complete a game in under 5 minutes",
    icon: "fire",
    points: 30,
    condition: JSON.stringify({ type: "speed_completion", value: 300 }),
    isActive: true,
  },
  {
    title: "Knowledge Seeker",
    description: "Earn 1000 total points",
    icon: "trophy",
    points: 100,
    condition: JSON.stringify({ type: "total_score", value: 1000 }),
    isActive: true,
  },
];

export async function seedDatabase() {
  console.log("🌱 Seeding database...");

  try {
    // Insert categories
    console.log("Inserting categories...");
    await db.insert(gameCategories).values(categories).onConflictDoNothing();

    // Insert games
    console.log("Inserting games...");
    await db.insert(games).values(sampleGames).onConflictDoNothing();

    // Insert questions
    console.log("Inserting questions...");
    await db.insert(gameQuestions).values(sampleQuestions).onConflictDoNothing();

    // Insert achievements
    console.log("Inserting achievements...");
    await db.insert(achievements).values(sampleAchievements).onConflictDoNothing();

    console.log("✅ Database seeded successfully!");
  } catch (error) {
    console.error("❌ Error seeding database:", error);
    throw error;
  }
}

// Run the seed function
seedDatabase()
  .then(() => {
    console.log("Seeding complete!");
    process.exit(0);
  })
  .catch((error) => {
    console.error("Seeding failed:", error);
    process.exit(1);
  });