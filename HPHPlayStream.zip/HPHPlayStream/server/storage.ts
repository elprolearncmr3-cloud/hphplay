import {
  users,
  games,
  gameCategories,
  gameQuestions,
  userGameProgress,
  gameSessions,
  achievements,
  userAchievements,
  type User,
  type UpsertUser,
  type Game,
  type GameCategory,
  type GameQuestion,
  type UserGameProgress,
  type GameSession,
  type Achievement,
  type UserAchievement,
  type InsertGame,
  type InsertGameSession,
  type InsertUserGameProgress,
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql, and, inArray } from "drizzle-orm";

export interface IStorage {
  // User operations - mandatory for Replit Auth
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;
  
  // Game operations
  getAllGames(): Promise<(Game & { category: GameCategory | null })[]>;
  getGamesByCategory(categoryId: number): Promise<(Game & { category: GameCategory | null })[]>;
  getGameById(id: number): Promise<(Game & { category: GameCategory | null }) | undefined>;
  getGameBySlug(slug: string): Promise<(Game & { category: GameCategory | null }) | undefined>;
  
  // Game categories
  getAllGameCategories(): Promise<GameCategory[]>;
  
  // Game questions
  getGameQuestions(gameId: number): Promise<GameQuestion[]>;
  
  // User progress
  getUserGameProgress(userId: string, gameId?: number): Promise<UserGameProgress[]>;
  upsertUserGameProgress(progress: InsertUserGameProgress): Promise<UserGameProgress>;
  
  // Game sessions
  createGameSession(session: InsertGameSession): Promise<GameSession>;
  getUserGameSessions(userId: string, gameId?: number): Promise<GameSession[]>;
  
  // Achievements
  getAllAchievements(): Promise<Achievement[]>;
  getUserAchievements(userId: string): Promise<(UserAchievement & { achievement: Achievement })[]>;
  checkAndUnlockAchievements(userId: string): Promise<UserAchievement[]>;
  
  // Statistics
  getUserStats(userId: string): Promise<{
    totalScore: number;
    gamesCompleted: number;
    hoursPlayed: number;
    streak: number;
  }>;
  
  getLeaderboard(limit?: number): Promise<Array<{
    user: User;
    totalScore: number;
    rank: number;
  }>>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Game operations
  async getAllGames(): Promise<(Game & { category: GameCategory | null })[]> {
    const result = await db
      .select()
      .from(games)
      .leftJoin(gameCategories, eq(games.categoryId, gameCategories.id))
      .where(eq(games.isActive, true))
      .orderBy(games.title);
    
    return result.map(row => ({
      ...row.games,
      category: row.game_categories
    }));
  }

  async getGamesByCategory(categoryId: number): Promise<(Game & { category: GameCategory | null })[]> {
    const result = await db
      .select()
      .from(games)
      .leftJoin(gameCategories, eq(games.categoryId, gameCategories.id))
      .where(and(eq(games.categoryId, categoryId), eq(games.isActive, true)))
      .orderBy(games.title);
    
    return result.map(row => ({
      ...row.games,
      category: row.game_categories
    }));
  }

  async getGameById(id: number): Promise<(Game & { category: GameCategory | null }) | undefined> {
    const result = await db
      .select()
      .from(games)
      .leftJoin(gameCategories, eq(games.categoryId, gameCategories.id))
      .where(eq(games.id, id));
    
    if (result.length === 0) return undefined;
    
    return {
      ...result[0].games,
      category: result[0].game_categories
    };
  }

  async getGameBySlug(slug: string): Promise<(Game & { category: GameCategory | null }) | undefined> {
    const result = await db
      .select()
      .from(games)
      .leftJoin(gameCategories, eq(games.categoryId, gameCategories.id))
      .where(eq(games.slug, slug));
    
    if (result.length === 0) return undefined;
    
    return {
      ...result[0].games,
      category: result[0].game_categories
    };
  }

  // Game categories
  async getAllGameCategories(): Promise<GameCategory[]> {
    return await db.select().from(gameCategories).orderBy(gameCategories.name);
  }

  // Game questions
  async getGameQuestions(gameId: number): Promise<GameQuestion[]> {
    return await db
      .select()
      .from(gameQuestions)
      .where(eq(gameQuestions.gameId, gameId))
      .orderBy(sql`RANDOM()`);
  }

  // User progress
  async getUserGameProgress(userId: string, gameId?: number): Promise<UserGameProgress[]> {
    const conditions = [eq(userGameProgress.userId, userId)];
    
    if (gameId) {
      conditions.push(eq(userGameProgress.gameId, gameId));
    }
    
    return await db
      .select()
      .from(userGameProgress)
      .where(and(...conditions))
      .orderBy(desc(userGameProgress.updatedAt));
  }

  async upsertUserGameProgress(progress: InsertUserGameProgress): Promise<UserGameProgress> {
    const [result] = await db
      .insert(userGameProgress)
      .values(progress)
      .onConflictDoUpdate({
        target: [userGameProgress.userId, userGameProgress.gameId],
        set: {
          ...progress,
          updatedAt: new Date(),
        },
      })
      .returning();
    return result;
  }

  // Game sessions
  async createGameSession(session: InsertGameSession): Promise<GameSession> {
    const [result] = await db
      .insert(gameSessions)
      .values(session)
      .returning();
    return result;
  }

  async getUserGameSessions(userId: string, gameId?: number): Promise<GameSession[]> {
    const conditions = [eq(gameSessions.userId, userId)];
    
    if (gameId) {
      conditions.push(eq(gameSessions.gameId, gameId));
    }
    
    return await db
      .select()
      .from(gameSessions)
      .where(and(...conditions))
      .orderBy(desc(gameSessions.createdAt));
  }

  // Achievements
  async getAllAchievements(): Promise<Achievement[]> {
    return await db
      .select()
      .from(achievements)
      .where(eq(achievements.isActive, true))
      .orderBy(achievements.title);
  }

  async getUserAchievements(userId: string): Promise<(UserAchievement & { achievement: Achievement })[]> {
    const result = await db
      .select()
      .from(userAchievements)
      .innerJoin(achievements, eq(userAchievements.achievementId, achievements.id))
      .where(eq(userAchievements.userId, userId))
      .orderBy(desc(userAchievements.unlockedAt));
    
    return result.map(row => ({
      ...row.user_achievements,
      achievement: row.achievements
    }));
  }

  async checkAndUnlockAchievements(userId: string): Promise<UserAchievement[]> {
    // This would contain the logic to check achievement conditions
    // and unlock new achievements based on user progress
    // For now, return empty array - implement specific achievement logic as needed
    return [];
  }

  // Statistics
  async getUserStats(userId: string): Promise<{
    totalScore: number;
    gamesCompleted: number;
    hoursPlayed: number;
    streak: number;
  }> {
    const progressResult = await db
      .select({
        totalScore: sql<number>`COALESCE(SUM(${userGameProgress.totalScore}), 0)`,
        gamesCompleted: sql<number>`COUNT(CASE WHEN ${userGameProgress.completed} = true THEN 1 END)`,
        hoursPlayed: sql<number>`COALESCE(SUM(${userGameProgress.totalTimeSpent}), 0) / 3600`,
      })
      .from(userGameProgress)
      .where(eq(userGameProgress.userId, userId));

    const stats = progressResult[0] || { totalScore: 0, gamesCompleted: 0, hoursPlayed: 0 };
    
    // Calculate streak (simplified - days played consecutively)
    const recentSessions = await db
      .select({ date: sql<string>`DATE(${gameSessions.createdAt})` })
      .from(gameSessions)
      .where(eq(gameSessions.userId, userId))
      .orderBy(desc(gameSessions.createdAt))
      .limit(30);

    let streak = 0;
    const today = new Date().toISOString().split('T')[0];
    const dates = Array.from(new Set(recentSessions.map(s => s.date)));
    
    for (let i = 0; i < dates.length; i++) {
      const currentDate = new Date(today);
      currentDate.setDate(currentDate.getDate() - i);
      const expectedDate = currentDate.toISOString().split('T')[0];
      
      if (dates[i] === expectedDate) {
        streak++;
      } else {
        break;
      }
    }

    return {
      totalScore: Number(stats.totalScore),
      gamesCompleted: Number(stats.gamesCompleted),
      hoursPlayed: Math.round(Number(stats.hoursPlayed)),
      streak,
    };
  }

  async getLeaderboard(limit = 10): Promise<Array<{
    user: User;
    totalScore: number;
    rank: number;
  }>> {
    const result = await db
      .select({
        user: users,
        totalScore: sql<number>`COALESCE(SUM(${userGameProgress.totalScore}), 0)`,
      })
      .from(users)
      .leftJoin(userGameProgress, eq(users.id, userGameProgress.userId))
      .groupBy(users.id)
      .orderBy(desc(sql<number>`COALESCE(SUM(${userGameProgress.totalScore}), 0)`))
      .limit(limit);

    return result.map((row, index) => ({
      user: row.user,
      totalScore: Number(row.totalScore),
      rank: index + 1,
    }));
  }
}

export const storage = new DatabaseStorage();
