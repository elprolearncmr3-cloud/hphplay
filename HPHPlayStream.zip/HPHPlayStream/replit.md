# Overview

HPHPlay is an educational gaming platform that combines learning with entertainment across multiple subjects including mathematics, science, languages, business, and general knowledge. The application features a full-stack architecture with interactive games supporting different modes (quiz, QCM, QRO), user progress tracking, achievements, leaderboards, and comprehensive analytics. The platform aims to make education engaging through gamification while providing detailed insights into learning progress.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite for build tooling
- **Routing**: Wouter for client-side routing with authentication-based route protection
- **State Management**: TanStack Query for server state management and caching
- **UI Framework**: Radix UI components with shadcn/ui design system
- **Styling**: Tailwind CSS with CSS variables for theming and dark mode support
- **Component Structure**: Modular component architecture with separate game components for different subjects (math, science, language, trivia)

## Backend Architecture
- **Runtime**: Node.js with Express.js server framework
- **Language**: TypeScript with ES modules
- **Database**: PostgreSQL with Drizzle ORM for type-safe database operations
- **Session Management**: Express sessions with PostgreSQL session store
- **API Design**: RESTful endpoints with consistent error handling and logging middleware

## Authentication & Authorization
- **Provider**: Replit OpenID Connect (OIDC) integration using Passport.js
- **Session Storage**: Database-backed sessions using connect-pg-simple
- **Security**: HTTP-only cookies with secure flags and CSRF protection
- **User Management**: Automatic user creation/update on successful authentication

## Database Design
- **Schema Management**: Drizzle with migration support
- **Core Entities**: Users, Games, GameCategories, GameQuestions, UserGameProgress, GameSessions, Achievements, UserAchievements
- **Relationships**: Relational design with foreign keys and proper indexing
- **Data Types**: Support for JSON fields for flexible game options and metadata

## Game Engine
- **Game Types**: Multiple game modes (quiz, QCM, QRO) with subject-specific implementations
- **Progress Tracking**: Real-time score calculation, completion rates, and time tracking
- **Achievement System**: Unlock-based achievements with badge display
- **Session Management**: Individual game session tracking with statistics

## Development & Deployment
- **Build System**: Vite for frontend with esbuild for backend compilation
- **Development**: Hot reload with Vite middleware integration
- **Environment**: Replit-optimized with cartographer plugin for development
- **Type Safety**: Full TypeScript coverage with strict compiler options

# External Dependencies

## Database & Storage
- **Neon PostgreSQL**: Serverless PostgreSQL database with connection pooling
- **Drizzle ORM**: Type-safe database operations with schema management
- **Database URL**: Environment-based connection string configuration

## Authentication Services
- **Replit OIDC**: Primary authentication provider for user management
- **Session Store**: PostgreSQL-backed session storage for security

## UI & Design System
- **Radix UI**: Comprehensive accessible component primitives
- **Tailwind CSS**: Utility-first CSS framework with custom configuration
- **Lucide React**: Icon library for consistent iconography
- **React Icons**: Additional icon sets (FontAwesome) for social media links

## Development Tools
- **Replit Integration**: Cartographer plugin for enhanced development experience
- **Runtime Error Overlay**: Development error handling with @replit/vite-plugin-runtime-error-modal
- **TypeScript**: Full type safety across frontend and backend

## Build & Bundling
- **Vite**: Frontend build tool with React plugin
- **esbuild**: Backend compilation for production deployment
- **PostCSS**: CSS processing with Tailwind and Autoprefixer