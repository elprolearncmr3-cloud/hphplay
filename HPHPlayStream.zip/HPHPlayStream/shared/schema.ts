import { sql } from 'drizzle-orm';
import {
  index,
  jsonb,
  pgTable,
  timestamp,
  varchar,
  text,
  integer,
  decimal,
  boolean,
  serial
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table - mandatory for Replit Auth
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table - mandatory for Replit Auth
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  dateOfBirth: timestamp("date_of_birth"),
  preferredLanguage: varchar("preferred_language").default("en"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Game categories
export const gameCategories = pgTable("game_categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }),
  color: varchar("color", { length: 20 }),
  createdAt: timestamp("created_at").defaultNow(),
});

// Games
export const games = pgTable("games", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  slug: varchar("slug", { length: 200 }).notNull().unique(),
  description: text("description"),
  categoryId: integer("category_id").references(() => gameCategories.id),
  difficulty: varchar("difficulty", { length: 20 }).default("beginner"), // beginner, intermediate, advanced
  gameType: varchar("game_type", { length: 50 }).notNull(), // quiz, qcm, puzzle, simulation, etc.
  imageUrl: varchar("image_url"),
  isActive: boolean("is_active").default(true),
  minAge: integer("min_age").default(5),
  estimatedDuration: integer("estimated_duration"), // in minutes
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Game questions for quiz-based games
export const gameQuestions = pgTable("game_questions", {
  id: serial("id").primaryKey(),
  gameId: integer("game_id").references(() => games.id),
  question: text("question").notNull(),
  options: jsonb("options"), // Array of answer options for multiple choice
  correctAnswer: text("correct_answer").notNull(),
  explanation: text("explanation"),
  difficulty: varchar("difficulty", { length: 20 }).default("beginner"),
  points: integer("points").default(10),
  createdAt: timestamp("created_at").defaultNow(),
});

// User game progress
export const userGameProgress = pgTable("user_game_progress", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  gameId: integer("game_id").references(() => games.id),
  totalScore: integer("total_score").default(0),
  highestScore: integer("highest_score").default(0),
  timesPlayed: integer("times_played").default(0),
  completed: boolean("completed").default(false),
  completionRate: decimal("completion_rate", { precision: 5, scale: 2 }).default("0"),
  totalTimeSpent: integer("total_time_spent").default(0), // in seconds
  lastPlayedAt: timestamp("last_played_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Game sessions
export const gameSessions = pgTable("game_sessions", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  gameId: integer("game_id").references(() => games.id),
  score: integer("score").default(0),
  questionsAnswered: integer("questions_answered").default(0),
  correctAnswers: integer("correct_answers").default(0),
  timeSpent: integer("time_spent").default(0), // in seconds
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Achievements
export const achievements = pgTable("achievements", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }),
  condition: jsonb("condition"), // Achievement unlock conditions
  points: integer("points").default(0),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// User achievements
export const userAchievements = pgTable("user_achievements", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  achievementId: integer("achievement_id").references(() => achievements.id),
  unlockedAt: timestamp("unlocked_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  gameProgress: many(userGameProgress),
  gameSessions: many(gameSessions),
  achievements: many(userAchievements),
}));

export const gameCategoriesRelations = relations(gameCategories, ({ many }) => ({
  games: many(games),
}));

export const gamesRelations = relations(games, ({ one, many }) => ({
  category: one(gameCategories, {
    fields: [games.categoryId],
    references: [gameCategories.id],
  }),
  questions: many(gameQuestions),
  progress: many(userGameProgress),
  sessions: many(gameSessions),
}));

export const gameQuestionsRelations = relations(gameQuestions, ({ one }) => ({
  game: one(games, {
    fields: [gameQuestions.gameId],
    references: [games.id],
  }),
}));

export const userGameProgressRelations = relations(userGameProgress, ({ one }) => ({
  user: one(users, {
    fields: [userGameProgress.userId],
    references: [users.id],
  }),
  game: one(games, {
    fields: [userGameProgress.gameId],
    references: [games.id],
  }),
}));

export const gameSessionsRelations = relations(gameSessions, ({ one }) => ({
  user: one(users, {
    fields: [gameSessions.userId],
    references: [users.id],
  }),
  game: one(games, {
    fields: [gameSessions.gameId],
    references: [games.id],
  }),
}));

export const achievementsRelations = relations(achievements, ({ many }) => ({
  userAchievements: many(userAchievements),
}));

export const userAchievementsRelations = relations(userAchievements, ({ one }) => ({
  user: one(users, {
    fields: [userAchievements.userId],
    references: [users.id],
  }),
  achievement: one(achievements, {
    fields: [userAchievements.achievementId],
    references: [achievements.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertGameSchema = createInsertSchema(games).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertGameSessionSchema = createInsertSchema(gameSessions).omit({
  id: true,
  createdAt: true,
});

export const insertUserGameProgressSchema = createInsertSchema(userGameProgress).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type GameCategory = typeof gameCategories.$inferSelect;
export type Game = typeof games.$inferSelect;
export type GameQuestion = typeof gameQuestions.$inferSelect;
export type UserGameProgress = typeof userGameProgress.$inferSelect;
export type GameSession = typeof gameSessions.$inferSelect;
export type Achievement = typeof achievements.$inferSelect;
export type UserAchievement = typeof userAchievements.$inferSelect;

export type InsertGame = z.infer<typeof insertGameSchema>;
export type InsertGameSession = z.infer<typeof insertGameSessionSchema>;
export type InsertUserGameProgress = z.infer<typeof insertUserGameProgressSchema>;
