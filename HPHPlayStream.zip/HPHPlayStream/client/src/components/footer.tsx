import { Link } from "wouter";
import { Gamepad2 } from "lucide-react";
import { FaFacebook, FaTwitter, FaInstagram, FaYoutube } from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-foreground text-background py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
                <Gamepad2 className="text-primary-foreground" size={24} />
              </div>
              <h3 className="text-2xl font-bold">HPHPlay</h3>
            </div>
            <p className="text-background/80">
              Making education fun and accessible through interactive gaming experiences.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-background/60 hover:text-background transition-colors" data-testid="link-facebook">
                <FaFacebook size={20} />
              </a>
              <a href="#" className="text-background/60 hover:text-background transition-colors" data-testid="link-twitter">
                <FaTwitter size={20} />
              </a>
              <a href="#" className="text-background/60 hover:text-background transition-colors" data-testid="link-instagram">
                <FaInstagram size={20} />
              </a>
              <a href="#" className="text-background/60 hover:text-background transition-colors" data-testid="link-youtube">
                <FaYoutube size={20} />
              </a>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Games</h4>
            <ul className="space-y-2">
              <li><Link href="/games?category=mathematics" className="text-background/80 hover:text-background transition-colors">Mathematics</Link></li>
              <li><Link href="/games?category=science" className="text-background/80 hover:text-background transition-colors">Science</Link></li>
              <li><Link href="/games?category=languages" className="text-background/80 hover:text-background transition-colors">Languages</Link></li>
              <li><Link href="/games?category=business" className="text-background/80 hover:text-background transition-colors">Business</Link></li>
              <li><Link href="/games?category=entertainment" className="text-background/80 hover:text-background transition-colors">Entertainment</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Support</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-background/80 hover:text-background transition-colors">Help Center</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors">Bug Reports</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors">Feature Requests</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors">Community</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-lg font-semibold mb-4">Company</h4>
            <ul className="space-y-2">
              <li><a href="#" className="text-background/80 hover:text-background transition-colors">About</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors">Careers</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors">Terms of Service</a></li>
              <li><a href="#" className="text-background/80 hover:text-background transition-colors">Blog</a></li>
            </ul>
          </div>
        </div>

        <div className="border-t border-background/20 mt-12 pt-8 text-center">
          <p className="text-background/60">
            &copy; 2024 HPHPlay. All rights reserved. Made with ❤️ for students worldwide.
          </p>
        </div>
      </div>
    </footer>
  );
}
