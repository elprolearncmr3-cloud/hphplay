import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Star, Users } from "lucide-react";
import { Game } from "@/types/game";
import { cn } from "@/lib/utils";

interface GameCardProps {
  game: Game;
  playerCount?: number;
  rating?: number;
}

export default function GameCard({ game, playerCount = 0, rating = 4.5 }: GameCardProps) {
  const getCategoryClass = (categoryName: string) => {
    const name = categoryName.toLowerCase().replace(/\s+/g, "-");
    return `category-${name}`;
  };

  const getGameImage = () => {
    if (game.imageUrl) return game.imageUrl;
    
    // Default images based on category
    const categoryImages: Record<string, string> = {
      mathematics: "https://images.unsplash.com/photo-1596495578065-6e0763fa1178?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      science: "https://images.unsplash.com/photo-1532094349884-543bc11b234d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      languages: "https://images.unsplash.com/photo-1481627834876-b7833e8f5570?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      business: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      physics: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      entertainment: "https://images.unsplash.com/photo-1493711662062-fa541adb3fc8?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      "computer-science": "https://images.unsplash.com/photo-1461749280684-dccba630e2f6?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
      "general-knowledge": "https://images.unsplash.com/photo-1488646953014-85cb44e25828?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=250",
    };
    
    const categorySlug = game.category?.slug || "general-knowledge";
    return categoryImages[categorySlug] || categoryImages["general-knowledge"];
  };

  return (
    <Card className="game-card bg-card rounded-lg overflow-hidden shadow-lg border border-border cursor-pointer" data-testid={`card-game-${game.id}`}>
      <img 
        src={getGameImage()} 
        alt={game.title} 
        className="w-full h-48 object-cover"
        loading="lazy"
      />
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <Badge 
            className={cn(
              "text-sm font-medium rounded-full",
              game.category ? getCategoryClass(game.category.name) : "bg-gray-100 text-gray-600"
            )}
            data-testid={`badge-category-${game.category?.slug || "unknown"}`}
          >
            {game.category?.name || "Uncategorized"}
          </Badge>
          <div className="flex items-center text-accent">
            <Star className="w-4 h-4 fill-current" />
            <span className="ml-1 text-sm font-medium" data-testid={`text-rating-${game.id}`}>
              {rating.toFixed(1)}
            </span>
          </div>
        </div>
        
        <h3 className="text-lg font-semibold text-card-foreground mb-2" data-testid={`text-game-title-${game.id}`}>
          {game.title}
        </h3>
        
        <p className="text-muted-foreground text-sm mb-4 line-clamp-2" data-testid={`text-game-description-${game.id}`}>
          {game.description || "Experience this exciting educational game!"}
        </p>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center text-sm text-muted-foreground">
            <Users className="w-4 h-4 mr-1" />
            <span data-testid={`text-player-count-${game.id}`}>
              {playerCount > 0 ? `${playerCount.toLocaleString()} playing` : "New game"}
            </span>
          </div>
          
          <Button asChild className="btn-primary" data-testid={`button-play-${game.id}`}>
            <Link href={`/games/${game.slug}`}>
              Play Now
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
