import { Link } from "wouter";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Bell, Gamepad2, Search } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { User } from "@/types/game";
import { useState } from "react";

interface NavigationProps {
  showSearch?: boolean;
}

export default function Navigation({ showSearch = true }: NavigationProps) {
  const { user, isAuthenticated } = useAuth();
  const [searchQuery, setSearchQuery] = useState("");

  const getInitials = () => {
    const typedUser = user as User | undefined;
    if (typedUser?.firstName && typedUser?.lastName) {
      return `${typedUser.firstName[0]}${typedUser.lastName[0]}`.toUpperCase();
    }
    return typedUser?.email?.[0]?.toUpperCase() || "U";
  };

  const getDisplayName = () => {
    const typedUser = user as User | undefined;
    if (typedUser?.firstName && typedUser?.lastName) {
      return `${typedUser.firstName} ${typedUser.lastName}`;
    }
    return typedUser?.email || "User";
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-card/95 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link href="/" className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Gamepad2 className="text-primary-foreground" size={24} />
            </div>
            <h1 className="text-2xl font-bold text-foreground">HPHPlay</h1>
          </Link>
          
          {/* Navigation Links */}
          {isAuthenticated && (
            <div className="hidden md:flex items-center space-x-8">
              <Link href="/" className="nav-link px-3 py-2 rounded-md text-sm font-medium text-foreground transition-colors">
                Home
              </Link>
              <Link href="/games" className="nav-link px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Games
              </Link>
              <Link href="/dashboard" className="nav-link px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Dashboard
              </Link>
              <Link href="/leaderboard" className="nav-link px-3 py-2 rounded-md text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
                Leaderboard
              </Link>
            </div>
          )}
          
          {/* User Actions */}
          <div className="flex items-center space-x-4">
            {showSearch && isAuthenticated && (
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Search games..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-2 bg-muted rounded-lg border-0 focus:ring-2 focus:ring-primary text-sm w-64"
                  data-testid="input-search-games"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={16} />
              </div>
            )}
            
            {isAuthenticated ? (
              <div className="flex items-center space-x-2">
                {/* Notification Bell */}
                <Button variant="ghost" size="icon" className="relative" data-testid="button-notifications">
                  <Bell size={20} className="text-muted-foreground" />
                  <span className="absolute -top-1 -right-1 w-5 h-5 bg-destructive text-destructive-foreground text-xs rounded-full flex items-center justify-center">
                    3
                  </span>
                </Button>
                
                {/* User Profile */}
                <div className="flex items-center space-x-3 cursor-pointer hover:bg-muted rounded-lg p-2 transition-colors">
                  <Avatar className="w-8 h-8">
                    <AvatarImage src={(user as User)?.profileImageUrl || ""} alt={getDisplayName()} />
                    <AvatarFallback className="bg-primary text-primary-foreground text-sm font-medium">
                      {getInitials()}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-sm font-medium text-foreground" data-testid="text-user-name">
                    {getDisplayName()}
                  </span>
                </div>
              </div>
            ) : (
              <Button asChild className="btn-primary" data-testid="button-login">
                <a href="/api/login">Sign In</a>
              </Button>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
