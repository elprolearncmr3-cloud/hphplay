import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, BookOpen, Timer, Volume2, Eye } from "lucide-react";
import { Game, GameQuestion } from "@/types/game";

interface LanguageGameProps {
  game: Game;
  questions: GameQuestion[];
  gameMode: "quiz" | "qcm" | "qro";
  onGameEnd: (score: number, questionsAnswered: number, correctAnswers: number) => void;
  onGameReset: () => void;
}

export default function LanguageGame({ game, questions, gameMode, onGameEnd }: LanguageGameProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [selectedOption, setSelectedOption] = useState<string>("");
  const [score, setScore] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [timeLeft, setTimeLeft] = useState(45); // 45 seconds per question for language
  const [gameStarted, setGameStarted] = useState(false);
  const [showTranslation, setShowTranslation] = useState(false);
  const [streak, setStreak] = useState(0);

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  useEffect(() => {
    if (!gameStarted) {
      setGameStarted(true);
    }
  }, [gameStarted]);

  useEffect(() => {
    if (gameStarted && timeLeft > 0 && !showFeedback) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showFeedback) {
      handleTimeUp();
    }
  }, [timeLeft, showFeedback, gameStarted]);

  const handleTimeUp = () => {
    setShowFeedback(true);
    setIsCorrect(false);
    setStreak(0);
  };

  const checkAnswer = () => {
    let userResponse = "";

    if (gameMode === "qcm") {
      userResponse = selectedOption;
    } else {
      userResponse = userAnswer.trim();
    }

    const actualCorrect = currentQuestion.correctAnswer;
    const answeredCorrectly = userResponse.toLowerCase() === actualCorrect.toLowerCase() ||
                             userResponse === actualCorrect;

    setIsCorrect(answeredCorrectly);
    setShowFeedback(true);

    if (answeredCorrectly) {
      const basePoints = currentQuestion.points || 12;
      const timeBonus = Math.floor(timeLeft / 5) * 2;
      const streakBonus = streak >= 3 ? 10 : 0;
      const translationPenalty = showTranslation ? 3 : 0;
      const points = Math.max(basePoints + timeBonus + streakBonus - translationPenalty, 5);
      setScore(score + points);
      setCorrectAnswers(correctAnswers + 1);
      setStreak(streak + 1);
    } else {
      setStreak(0);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setUserAnswer("");
      setSelectedOption("");
      setShowFeedback(false);
      setShowTranslation(false);
      setTimeLeft(45);
    } else {
      onGameEnd(score, questions.length, correctAnswers);
    }
  };

  const renderOptions = () => {
    if (gameMode !== "qcm" || !currentQuestion.options) return null;

    const options = Array.isArray(currentQuestion.options) 
      ? currentQuestion.options 
      : JSON.parse(currentQuestion.options as string);

    return (
      <div className="grid grid-cols-1 gap-3">
        {options.map((option: string, index: number) => (
          <Button
            key={index}
            variant={selectedOption === option ? "default" : "outline"}
            className="h-auto p-4 text-left justify-start whitespace-normal"
            onClick={() => setSelectedOption(option)}
            disabled={showFeedback}
            data-testid={`button-option-${index}`}
          >
            <span className="font-medium mr-2">{String.fromCharCode(65 + index)}.</span>
            {option}
          </Button>
        ))}
      </div>
    );
  };

  const renderInput = () => {
    if (gameMode === "qcm") return null;

    return (
      <div className="space-y-4">
        <Input
          type="text"
          placeholder="Type your answer..."
          value={userAnswer}
          onChange={(e) => setUserAnswer(e.target.value)}
          className="text-lg"
          disabled={showFeedback}
          data-testid="input-answer"
        />
        <div className="text-sm text-muted-foreground text-center">
          {gameMode === "qro" ? "Type your complete answer" : "Enter the correct word or phrase"}
        </div>
      </div>
    );
  };

  const playPronunciation = () => {
    // In a real implementation, this would use text-to-speech
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(currentQuestion.question);
      utterance.lang = 'en-US'; // or detect language from game context
      speechSynthesis.speak(utterance);
    }
  };

  const getTranslationHint = () => {
    // This would normally come from a translation service
    const hints = [
      "This word is commonly used in everyday conversation.",
      "Think about the context in which this phrase might be used.",
      "Consider the grammatical structure of the sentence.",
      "This is a common expression in formal writing.",
      "Break down the sentence into individual components.",
    ];
    return hints[Math.floor(Math.random() * hints.length)];
  };

  if (!currentQuestion) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <p className="text-muted-foreground">No questions available for this game.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Game Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary" data-testid="text-current-score">
              {score}
            </div>
            <div className="text-sm text-muted-foreground">Score</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600" data-testid="text-correct-answers">
              {correctAnswers}
            </div>
            <div className="text-sm text-muted-foreground">Correct</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600" data-testid="text-question-progress">
              {currentQuestionIndex + 1}/{questions.length}
            </div>
            <div className="text-sm text-muted-foreground">Question</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600" data-testid="text-streak">
              {streak}
            </div>
            <div className="text-sm text-muted-foreground">Streak</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center space-x-1">
              <Timer className="w-4 h-4" />
              <span className={`text-2xl font-bold ${timeLeft <= 10 ? "text-red-600" : "text-orange-600"}`} data-testid="text-time-left">
                {timeLeft}s
              </span>
            </div>
            <div className="text-sm text-muted-foreground">Time</div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Bar */}
      <div>
        <div className="flex justify-between text-sm text-muted-foreground mb-2">
          <span>Progress</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Streak Indicator */}
      {streak >= 3 && (
        <Card className="border-orange-200 bg-orange-50 dark:bg-orange-900/20">
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center space-x-2 text-orange-700 dark:text-orange-300">
              <BookOpen className="w-5 h-5" />
              <span className="font-medium" data-testid="text-streak-bonus">
                🔥 {streak} in a row! Streak bonus active!
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Question Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <BookOpen className="w-5 h-5 text-purple-600" />
              <CardTitle className="text-lg">
                Language Challenge {currentQuestionIndex + 1}
              </CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" data-testid="badge-question-points">
                {currentQuestion.points || 12} points
              </Badge>
              <Badge variant="outline" className="category-languages">
                {currentQuestion.difficulty || "Beginner"}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-xl font-semibold" data-testid="text-question">
                {currentQuestion.question}
              </h3>
              <Button
                variant="ghost"
                size="sm"
                onClick={playPronunciation}
                className="flex items-center space-x-1"
                data-testid="button-pronunciation"
              >
                <Volume2 className="w-4 h-4" />
                <span className="text-sm">Listen</span>
              </Button>
            </div>
          </div>

          {!showFeedback && (
            <div className="space-y-4">
              {renderOptions()}
              {renderInput()}
              
              {/* Help Section */}
              <div className="border-t pt-4 space-y-2">
                {!showTranslation ? (
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => setShowTranslation(true)}
                    className="text-muted-foreground"
                    data-testid="button-show-hint"
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Need help? (-3 points)
                  </Button>
                ) : (
                  <div className="bg-purple-50 dark:bg-purple-900/20 p-3 rounded-lg">
                    <div className="flex items-start space-x-2">
                      <Eye className="w-4 h-4 text-purple-600 mt-0.5" />
                      <div>
                        <p className="text-sm font-medium text-purple-700 dark:text-purple-300">Hint:</p>
                        <p className="text-sm text-purple-600 dark:text-purple-400" data-testid="text-hint">
                          {getTranslationHint()}
                        </p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="text-center">
                <Button 
                  onClick={checkAnswer}
                  disabled={(!userAnswer && !selectedOption) || showFeedback}
                  className="px-8"
                  data-testid="button-submit-answer"
                >
                  Submit Answer
                </Button>
              </div>
            </div>
          )}

          {showFeedback && (
            <div className="space-y-4">
              <div className={`flex items-center justify-center space-x-2 p-4 rounded-lg ${
                isCorrect ? "bg-green-50 text-green-700 dark:bg-green-900/20" : "bg-red-50 text-red-700 dark:bg-red-900/20"
              }`}>
                {isCorrect ? (
                  <CheckCircle className="w-6 h-6" />
                ) : (
                  <XCircle className="w-6 h-6" />
                )}
                <span className="font-medium" data-testid="text-feedback">
                  {isCorrect ? "Perfect!" : "Keep practicing!"}
                </span>
              </div>

              {!isCorrect && (
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <p className="font-medium">Correct Answer:</p>
                  <p className="text-lg" data-testid="text-correct-answer">
                    {currentQuestion.correctAnswer}
                  </p>
                  {currentQuestion.explanation && (
                    <div className="mt-3 text-sm text-muted-foreground">
                      <p className="font-medium">Explanation:</p>
                      <p>{currentQuestion.explanation}</p>
                    </div>
                  )}
                </div>
              )}

              <div className="text-center">
                <Button 
                  onClick={handleNextQuestion}
                  className="px-8"
                  data-testid="button-next-question"
                >
                  {currentQuestionIndex < questions.length - 1 ? "Continue Learning" : "Complete Lesson"}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
