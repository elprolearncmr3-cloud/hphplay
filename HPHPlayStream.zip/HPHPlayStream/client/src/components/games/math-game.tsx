import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Calculator, Timer, Star } from "lucide-react";
import { Game, GameQuestion } from "@/types/game";

interface MathGameProps {
  game: Game;
  questions: GameQuestion[];
  gameMode: "quiz" | "qcm" | "qro";
  onGameEnd: (score: number, questionsAnswered: number, correctAnswers: number) => void;
  onGameReset: () => void;
}

export default function MathGame({ game, questions, gameMode, onGameEnd }: MathGameProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [selectedOption, setSelectedOption] = useState<string>("");
  const [score, setScore] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [timeLeft, setTimeLeft] = useState(60); // 60 seconds per question
  const [gameStarted, setGameStarted] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  useEffect(() => {
    if (!gameStarted) {
      setGameStarted(true);
    }
  }, [gameStarted]);

  useEffect(() => {
    if (gameStarted && timeLeft > 0 && !showFeedback) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showFeedback) {
      handleTimeUp();
    }
  }, [timeLeft, showFeedback, gameStarted]);

  const handleTimeUp = () => {
    setShowFeedback(true);
    setIsCorrect(false);
  };

  const generateMathProblem = () => {
    // Generate dynamic math problems based on difficulty
    const difficulty = game.difficulty || "beginner";
    let num1, num2, operation, correctAnswer;

    switch (difficulty) {
      case "advanced":
        num1 = Math.floor(Math.random() * 100) + 10;
        num2 = Math.floor(Math.random() * 100) + 10;
        operation = ["+", "-", "*", "/"][Math.floor(Math.random() * 4)];
        break;
      case "intermediate":
        num1 = Math.floor(Math.random() * 50) + 5;
        num2 = Math.floor(Math.random() * 50) + 5;
        operation = ["+", "-", "*"][Math.floor(Math.random() * 3)];
        break;
      default:
        num1 = Math.floor(Math.random() * 20) + 1;
        num2 = Math.floor(Math.random() * 20) + 1;
        operation = ["+", "-"][Math.floor(Math.random() * 2)];
    }

    switch (operation) {
      case "+":
        correctAnswer = num1 + num2;
        break;
      case "-":
        correctAnswer = num1 - num2;
        break;
      case "*":
        correctAnswer = num1 * num2;
        break;
      case "/":
        correctAnswer = parseFloat((num1 / num2).toFixed(2));
        break;
      default:
        correctAnswer = num1 + num2;
    }

    return {
      question: `${num1} ${operation} ${num2} = ?`,
      correctAnswer: correctAnswer.toString(),
      options: gameMode === "qcm" ? generateOptions(correctAnswer) : null,
    };
  };

  const generateOptions = (correct: number) => {
    const options = [correct];
    while (options.length < 4) {
      const wrong = correct + Math.floor(Math.random() * 20) - 10;
      if (!options.includes(wrong) && wrong !== correct) {
        options.push(wrong);
      }
    }
    return options.sort(() => Math.random() - 0.5);
  };

  const checkAnswer = () => {
    const mathProblem = generateMathProblem();
    const correct = mathProblem.correctAnswer;
    let userResponse = "";

    if (gameMode === "qcm") {
      userResponse = selectedOption;
    } else {
      userResponse = userAnswer.trim();
    }

    // For demonstration, we'll use the current question's correct answer
    // In a real implementation, you'd parse the math expression
    const actualCorrect = currentQuestion.correctAnswer;
    const answeredCorrectly = userResponse.toLowerCase() === actualCorrect.toLowerCase() ||
                             parseFloat(userResponse) === parseFloat(actualCorrect);

    setIsCorrect(answeredCorrectly);
    setShowFeedback(true);

    if (answeredCorrectly) {
      const points = Math.max(10, Math.floor(timeLeft / 6) * 10); // Bonus for speed
      setScore(score + points);
      setCorrectAnswers(correctAnswers + 1);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setUserAnswer("");
      setSelectedOption("");
      setShowFeedback(false);
      setTimeLeft(60);
    } else {
      onGameEnd(score, questions.length, correctAnswers);
    }
  };

  const renderOptions = () => {
    if (gameMode !== "qcm" || !currentQuestion.options) return null;

    const options = Array.isArray(currentQuestion.options) 
      ? currentQuestion.options 
      : JSON.parse(currentQuestion.options as string);

    return (
      <div className="grid grid-cols-2 gap-3">
        {options.map((option: string, index: number) => (
          <Button
            key={index}
            variant={selectedOption === option ? "default" : "outline"}
            className="h-12 text-lg"
            onClick={() => setSelectedOption(option)}
            disabled={showFeedback}
            data-testid={`button-option-${index}`}
          >
            {option}
          </Button>
        ))}
      </div>
    );
  };

  const renderInput = () => {
    if (gameMode === "qcm") return null;

    return (
      <div className="space-y-4">
        <Input
          type="text"
          placeholder="Enter your answer..."
          value={userAnswer}
          onChange={(e) => setUserAnswer(e.target.value)}
          className="text-lg text-center"
          disabled={showFeedback}
          data-testid="input-answer"
        />
      </div>
    );
  };

  if (!currentQuestion) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <p className="text-muted-foreground">No questions available for this game.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Game Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary" data-testid="text-current-score">
              {score}
            </div>
            <div className="text-sm text-muted-foreground">Score</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600" data-testid="text-correct-answers">
              {correctAnswers}
            </div>
            <div className="text-sm text-muted-foreground">Correct</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600" data-testid="text-question-progress">
              {currentQuestionIndex + 1}/{questions.length}
            </div>
            <div className="text-sm text-muted-foreground">Question</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center space-x-1">
              <Timer className="w-4 h-4" />
              <span className={`text-2xl font-bold ${timeLeft <= 10 ? "text-red-600" : "text-orange-600"}`} data-testid="text-time-left">
                {timeLeft}s
              </span>
            </div>
            <div className="text-sm text-muted-foreground">Time Left</div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Bar */}
      <div>
        <div className="flex justify-between text-sm text-muted-foreground mb-2">
          <span>Progress</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Question Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Calculator className="w-5 h-5 text-primary" />
              <CardTitle className="text-lg">
                Question {currentQuestionIndex + 1}
              </CardTitle>
            </div>
            <Badge variant="outline" data-testid="badge-question-points">
              {currentQuestion.points || 10} points
            </Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <h3 className="text-2xl font-semibold mb-4" data-testid="text-question">
              {currentQuestion.question}
            </h3>
          </div>

          {!showFeedback && (
            <div className="space-y-4">
              {renderOptions()}
              {renderInput()}
              
              <div className="text-center">
                <Button 
                  onClick={checkAnswer}
                  disabled={(!userAnswer && !selectedOption) || showFeedback}
                  className="px-8"
                  data-testid="button-submit-answer"
                >
                  Submit Answer
                </Button>
              </div>
            </div>
          )}

          {showFeedback && (
            <div className="space-y-4">
              <div className={`flex items-center justify-center space-x-2 p-4 rounded-lg ${
                isCorrect ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"
              }`}>
                {isCorrect ? (
                  <CheckCircle className="w-6 h-6" />
                ) : (
                  <XCircle className="w-6 h-6" />
                )}
                <span className="font-medium" data-testid="text-feedback">
                  {isCorrect ? "Correct!" : "Incorrect"}
                </span>
              </div>

              {!isCorrect && (
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <p className="font-medium">Correct Answer:</p>
                  <p className="text-lg" data-testid="text-correct-answer">
                    {currentQuestion.correctAnswer}
                  </p>
                  {currentQuestion.explanation && (
                    <p className="text-sm text-muted-foreground mt-2">
                      {currentQuestion.explanation}
                    </p>
                  )}
                </div>
              )}

              <div className="text-center">
                <Button 
                  onClick={handleNextQuestion}
                  className="px-8"
                  data-testid="button-next-question"
                >
                  {currentQuestionIndex < questions.length - 1 ? "Next Question" : "Finish Game"}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
