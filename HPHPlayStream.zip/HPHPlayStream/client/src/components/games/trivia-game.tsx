import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, XCircle, Brain, Timer, Lightbulb, Zap } from "lucide-react";
import { Game, GameQuestion } from "@/types/game";

interface TriviaGameProps {
  game: Game;
  questions: GameQuestion[];
  gameMode: "quiz" | "qcm" | "qro";
  onGameEnd: (score: number, questionsAnswered: number, correctAnswers: number) => void;
  onGameReset: () => void;
}

export default function TriviaGame({ game, questions, gameMode, onGameEnd }: TriviaGameProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState("");
  const [selectedOption, setSelectedOption] = useState<string>("");
  const [score, setScore] = useState(0);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const [timeLeft, setTimeLeft] = useState(30); // 30 seconds per question for trivia
  const [gameStarted, setGameStarted] = useState(false);
  const [usedLifeline, setUsedLifeline] = useState(false);
  const [eliminatedOptions, setEliminatedOptions] = useState<string[]>([]);
  const [streak, setStreak] = useState(0);
  const [speedBonus, setSpeedBonus] = useState(false);

  const currentQuestion = questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

  useEffect(() => {
    if (!gameStarted) {
      setGameStarted(true);
    }
  }, [gameStarted]);

  useEffect(() => {
    if (gameStarted && timeLeft > 0 && !showFeedback) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
      return () => clearTimeout(timer);
    } else if (timeLeft === 0 && !showFeedback) {
      handleTimeUp();
    }
  }, [timeLeft, showFeedback, gameStarted]);

  const handleTimeUp = () => {
    setShowFeedback(true);
    setIsCorrect(false);
    setStreak(0);
    setSpeedBonus(false);
  };

  const checkAnswer = () => {
    let userResponse = "";

    if (gameMode === "qcm") {
      userResponse = selectedOption;
    } else {
      userResponse = userAnswer.trim();
    }

    const actualCorrect = currentQuestion.correctAnswer;
    const answeredCorrectly = userResponse.toLowerCase() === actualCorrect.toLowerCase();

    setIsCorrect(answeredCorrectly);
    setShowFeedback(true);

    if (answeredCorrectly) {
      const basePoints = currentQuestion.points || 10;
      const timeBonus = timeLeft >= 20 ? 15 : timeLeft >= 10 ? 10 : 5;
      const streakBonus = streak >= 2 ? streak * 5 : 0;
      const lifelinePenalty = usedLifeline ? 5 : 0;
      const speedBonusPoints = timeLeft >= 25 ? 20 : 0;
      
      if (timeLeft >= 25) setSpeedBonus(true);
      
      const points = Math.max(basePoints + timeBonus + streakBonus + speedBonusPoints - lifelinePenalty, 5);
      setScore(score + points);
      setCorrectAnswers(correctAnswers + 1);
      setStreak(streak + 1);
    } else {
      setStreak(0);
      setSpeedBonus(false);
    }
  };

  const handleNextQuestion = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setUserAnswer("");
      setSelectedOption("");
      setShowFeedback(false);
      setUsedLifeline(false);
      setEliminatedOptions([]);
      setSpeedBonus(false);
      setTimeLeft(30);
    } else {
      onGameEnd(score, questions.length, correctAnswers);
    }
  };

  const use5050Lifeline = () => {
    if (usedLifeline || gameMode !== "qcm" || !currentQuestion.options) return;

    const options = Array.isArray(currentQuestion.options) 
      ? currentQuestion.options 
      : JSON.parse(currentQuestion.options as string);

    const correctAnswer = currentQuestion.correctAnswer;
    const wrongOptions = options.filter((opt: string) => opt !== correctAnswer);
    
    // Randomly eliminate 2 wrong options
    const toEliminate = wrongOptions.sort(() => Math.random() - 0.5).slice(0, 2);
    setEliminatedOptions(toEliminate);
    setUsedLifeline(true);
  };

  const renderOptions = () => {
    if (gameMode !== "qcm" || !currentQuestion.options) return null;

    const options = Array.isArray(currentQuestion.options) 
      ? currentQuestion.options 
      : JSON.parse(currentQuestion.options as string);

    return (
      <div className="grid grid-cols-1 gap-3">
        {options.map((option: string, index: number) => {
          const isEliminated = eliminatedOptions.includes(option);
          
          return (
            <Button
              key={index}
              variant={selectedOption === option ? "default" : "outline"}
              className={`h-auto p-4 text-left justify-start whitespace-normal transition-all ${
                isEliminated ? "opacity-30 cursor-not-allowed" : ""
              }`}
              onClick={() => !isEliminated && setSelectedOption(option)}
              disabled={showFeedback || isEliminated}
              data-testid={`button-option-${index}`}
            >
              <span className="font-medium mr-2">{String.fromCharCode(65 + index)}.</span>
              <span className={isEliminated ? "line-through" : ""}>{option}</span>
            </Button>
          );
        })}
      </div>
    );
  };

  const renderInput = () => {
    if (gameMode === "qcm") return null;

    return (
      <div className="space-y-4">
        <Input
          type="text"
          placeholder="Enter your answer..."
          value={userAnswer}
          onChange={(e) => setUserAnswer(e.target.value)}
          className="text-lg"
          disabled={showFeedback}
          data-testid="input-answer"
        />
      </div>
    );
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty?.toLowerCase()) {
      case "advanced":
        return "text-red-600 bg-red-100 dark:bg-red-900/20";
      case "intermediate":
        return "text-orange-600 bg-orange-100 dark:bg-orange-900/20";
      default:
        return "text-green-600 bg-green-100 dark:bg-green-900/20";
    }
  };

  if (!currentQuestion) {
    return (
      <Card>
        <CardContent className="pt-6 text-center">
          <p className="text-muted-foreground">No questions available for this game.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Game Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-primary" data-testid="text-current-score">
              {score}
            </div>
            <div className="text-sm text-muted-foreground">Score</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600" data-testid="text-correct-answers">
              {correctAnswers}
            </div>
            <div className="text-sm text-muted-foreground">Correct</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600" data-testid="text-question-progress">
              {currentQuestionIndex + 1}/{questions.length}
            </div>
            <div className="text-sm text-muted-foreground">Question</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600" data-testid="text-streak">
              {streak}
            </div>
            <div className="text-sm text-muted-foreground">Streak</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center space-x-1">
              <Timer className="w-4 h-4" />
              <span className={`text-2xl font-bold ${timeLeft <= 5 ? "text-red-600" : timeLeft <= 10 ? "text-orange-600" : "text-green-600"}`} data-testid="text-time-left">
                {timeLeft}s
              </span>
            </div>
            <div className="text-sm text-muted-foreground">Time</div>
          </CardContent>
        </Card>
      </div>

      {/* Progress Bar */}
      <div>
        <div className="flex justify-between text-sm text-muted-foreground mb-2">
          <span>Progress</span>
          <span>{Math.round(progress)}%</span>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Speed Bonus Alert */}
      {speedBonus && (
        <Card className="border-yellow-200 bg-yellow-50 dark:bg-yellow-900/20">
          <CardContent className="p-4 text-center">
            <div className="flex items-center justify-center space-x-2 text-yellow-700 dark:text-yellow-300">
              <Zap className="w-5 h-5" />
              <span className="font-medium" data-testid="text-speed-bonus">
                ⚡ Lightning Fast! +20 Speed Bonus!
              </span>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Question Card */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Brain className="w-5 h-5 text-primary" />
              <CardTitle className="text-lg">
                Trivia Challenge {currentQuestionIndex + 1}
              </CardTitle>
            </div>
            <div className="flex items-center space-x-2">
              <Badge variant="outline" data-testid="badge-question-points">
                {currentQuestion.points || 10} points
              </Badge>
              <Badge 
                variant="outline" 
                className={getDifficultyColor(currentQuestion.difficulty || "beginner")}
              >
                {currentQuestion.difficulty || "Beginner"}
              </Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <h3 className="text-xl font-semibold mb-4" data-testid="text-question">
              {currentQuestion.question}
            </h3>
          </div>

          {!showFeedback && (
            <div className="space-y-4">
              {renderOptions()}
              {renderInput()}
              
              {/* Lifeline Section - Only for QCM */}
              {gameMode === "qcm" && (
                <div className="border-t pt-4">
                  <div className="flex justify-center">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={use5050Lifeline}
                      disabled={usedLifeline || showFeedback}
                      className="text-muted-foreground"
                      data-testid="button-lifeline"
                    >
                      <Lightbulb className="w-4 h-4 mr-2" />
                      50/50 Lifeline {usedLifeline ? "(Used)" : "(-5 points)"}
                    </Button>
                  </div>
                </div>
              )}
              
              <div className="text-center">
                <Button 
                  onClick={checkAnswer}
                  disabled={(!userAnswer && !selectedOption) || showFeedback}
                  className="px-8"
                  data-testid="button-submit-answer"
                >
                  Final Answer
                </Button>
              </div>
            </div>
          )}

          {showFeedback && (
            <div className="space-y-4">
              <div className={`flex items-center justify-center space-x-2 p-4 rounded-lg ${
                isCorrect ? "bg-green-50 text-green-700 dark:bg-green-900/20" : "bg-red-50 text-red-700 dark:bg-red-900/20"
              }`}>
                {isCorrect ? (
                  <CheckCircle className="w-6 h-6" />
                ) : (
                  <XCircle className="w-6 h-6" />
                )}
                <span className="font-medium" data-testid="text-feedback">
                  {isCorrect ? "Brilliant!" : "Not this time!"}
                </span>
              </div>

              {!isCorrect && (
                <div className="text-center p-4 bg-muted/50 rounded-lg">
                  <p className="font-medium">Correct Answer:</p>
                  <p className="text-lg" data-testid="text-correct-answer">
                    {currentQuestion.correctAnswer}
                  </p>
                  {currentQuestion.explanation && (
                    <div className="mt-3 text-sm text-muted-foreground">
                      <p className="font-medium">Did you know?</p>
                      <p>{currentQuestion.explanation}</p>
                    </div>
                  )}
                </div>
              )}

              <div className="text-center">
                <Button 
                  onClick={handleNextQuestion}
                  className="px-8"
                  data-testid="button-next-question"
                >
                  {currentQuestionIndex < questions.length - 1 ? "Next Challenge" : "View Results"}
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
