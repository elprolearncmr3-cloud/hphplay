import { Badge } from "@/components/ui/badge";
import { Trophy, Star, Flame, Target } from "lucide-react";
import { Achievement } from "@/types/game";
import { cn } from "@/lib/utils";

interface AchievementBadgeProps {
  achievement: Achievement;
  size?: "sm" | "md" | "lg";
  showTitle?: boolean;
}

export default function AchievementBadge({ 
  achievement, 
  size = "md", 
  showTitle = true 
}: AchievementBadgeProps) {
  const getIcon = (iconName: string | null) => {
    switch (iconName) {
      case "trophy":
        return Trophy;
      case "star":
        return Star;
      case "fire":
        return Flame;
      case "target":
        return Target;
      default:
        return Trophy;
    }
  };

  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12",
    lg: "w-16 h-16"
  };

  const iconSizes = {
    sm: 16,
    md: 20,
    lg: 24
  };

  const Icon = getIcon(achievement.icon);

  return (
    <div className="flex items-center space-x-3" data-testid={`badge-achievement-${achievement.id}`}>
      <div className={cn(
        "achievement-badge rounded-full flex items-center justify-center",
        sizeClasses[size]
      )}>
        <Icon className="text-white" size={iconSizes[size]} />
      </div>
      {showTitle && (
        <div>
          <div className="font-medium text-foreground" data-testid={`text-achievement-title-${achievement.id}`}>
            {achievement.title}
          </div>
          {achievement.description && (
            <div className="text-sm text-muted-foreground" data-testid={`text-achievement-description-${achievement.id}`}>
              {achievement.description}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
