export interface User {
  id: string;
  email: string | null;
  firstName: string | null;
  lastName: string | null;
  profileImageUrl: string | null;
  dateOfBirth: Date | null;
  preferredLanguage: string | null;
  createdAt: Date | null;
  updatedAt: Date | null;
}

export interface GameCategory {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  icon: string | null;
  color: string | null;
}

export interface Game {
  id: number;
  title: string;
  slug: string;
  description: string | null;
  categoryId: number | null;
  difficulty: string | null;
  gameType: string;
  imageUrl: string | null;
  isActive: boolean | null;
  minAge: number | null;
  estimatedDuration: number | null;
  category: GameCategory | null;
}

export interface GameQuestion {
  id: number;
  gameId: number | null;
  question: string;
  options: any;
  correctAnswer: string;
  explanation: string | null;
  difficulty: string | null;
  points: number | null;
}

export interface UserGameProgress {
  id: number;
  userId: string | null;
  gameId: number | null;
  totalScore: number | null;
  highestScore: number | null;
  timesPlayed: number | null;
  completed: boolean | null;
  completionRate: string | null;
  totalTimeSpent: number | null;
  lastPlayedAt: Date | null;
}

export interface GameSession {
  id: number;
  userId: string | null;
  gameId: number | null;
  score: number | null;
  questionsAnswered: number | null;
  correctAnswers: number | null;
  timeSpent: number | null;
  completedAt: Date | null;
}

export interface Achievement {
  id: number;
  title: string;
  description: string | null;
  icon: string | null;
  points: number | null;
}

export interface UserAchievement {
  id: number;
  userId: string | null;
  achievementId: number | null;
  unlockedAt: Date | null;
  achievement: Achievement;
}

export interface UserStats {
  totalScore: number;
  gamesCompleted: number;
  hoursPlayed: number;
  streak: number;
}

export interface LeaderboardEntry {
  user: {
    id: string;
    email: string | null;
    firstName: string | null;
    lastName: string | null;
    profileImageUrl: string | null;
  };
  totalScore: number;
  rank: number;
}
