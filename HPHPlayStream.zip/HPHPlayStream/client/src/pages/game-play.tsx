import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import MathGame from "@/components/games/math-game";
import ScienceGame from "@/components/games/science-game";
import LanguageGame from "@/components/games/language-game";
import TriviaGame from "@/components/games/trivia-game";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Play, RotateCcw, Trophy, Clock, Target } from "lucide-react";
import { Link } from "wouter";
import { Game, GameQuestion } from "@/types/game";

export default function GamePlay() {
  const { slug } = useParams<{ slug: string }>();
  const { toast } = useToast();
  const [gameMode, setGameMode] = useState<"quiz" | "qcm" | "qro">("quiz");
  const [isPlaying, setIsPlaying] = useState(false);
  const [gameSession, setGameSession] = useState<{
    score: number;
    questionsAnswered: number;
    correctAnswers: number;
    startTime: Date;
  } | null>(null);

  const { data: game, isLoading: gameLoading, error: gameError } = useQuery({
    queryKey: ["/api/games", slug],
    retry: false,
  });

  const { data: questions, isLoading: questionsLoading, error: questionsError } = useQuery({
    queryKey: ["/api/games", (game as Game)?.id, "questions"],
    enabled: !!(game as Game)?.id,
    retry: false,
  });

  const createSessionMutation = useMutation({
    mutationFn: async (sessionData: {
      gameId: number;
      score: number;
      questionsAnswered: number;
      correctAnswers: number;
      timeSpent: number;
    }) => {
      return await apiRequest("POST", "/api/game-sessions", sessionData);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user/progress"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user/stats"] });
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "Error",
        description: "Failed to save game session",
        variant: "destructive",
      });
    },
  });

  const updateProgressMutation = useMutation({
    mutationFn: async (progressData: {
      gameId: number;
      totalScore?: number;
      highestScore?: number;
      completed?: boolean;
      completionRate?: string;
      totalTimeSpent?: number;
    }) => {
      return await apiRequest("POST", "/api/user/progress", progressData);
    },
    onError: (error) => {
      if (isUnauthorizedError(error as Error)) {
        toast({
          title: "Unauthorized",
          description: "You are logged out. Logging in again...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
    },
  });

  useEffect(() => {
    const errors = [gameError, questionsError].filter(Boolean);
    const unauthorizedError = errors.find(error => isUnauthorizedError(error as Error));
    
    if (unauthorizedError) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [gameError, questionsError, toast]);

  const handleGameStart = () => {
    setIsPlaying(true);
    setGameSession({
      score: 0,
      questionsAnswered: 0,
      correctAnswers: 0,
      startTime: new Date(),
    });
  };

  const handleGameEnd = (finalScore: number, questionsAnswered: number, correctAnswers: number) => {
    const typedGame = game as Game;
    if (!typedGame || !gameSession) return;

    const timeSpent = Math.floor((Date.now() - gameSession.startTime.getTime()) / 1000);
    const completionRate = questionsAnswered > 0 ? (correctAnswers / questionsAnswered) * 100 : 0;

    // Create game session
    createSessionMutation.mutate({
      gameId: typedGame.id,
      score: finalScore,
      questionsAnswered,
      correctAnswers,
      timeSpent,
    });

    // Update user progress
    updateProgressMutation.mutate({
      gameId: typedGame.id,
      totalScore: finalScore,
      highestScore: finalScore,
      completed: completionRate >= 70,
      completionRate: completionRate.toFixed(2),
      totalTimeSpent: timeSpent,
    });

    setIsPlaying(false);
    setGameSession(null);

    toast({
      title: "Game Complete!",
      description: `You scored ${finalScore} points with ${correctAnswers}/${questionsAnswered} correct answers!`,
    });
  };

  const handleGameReset = () => {
    setIsPlaying(false);
    setGameSession(null);
  };

  const getCategoryClass = (categoryName: string) => {
    const name = categoryName.toLowerCase().replace(/\s+/g, "-");
    return `category-${name}`;
  };

  const renderGameComponent = () => {
    const typedGame = game as Game;
    const typedQuestions = questions as GameQuestion[];
    if (!typedGame || !typedQuestions) return null;

    const gameProps = {
      game: typedGame,
      questions: typedQuestions,
      gameMode,
      onGameEnd: handleGameEnd,
      onGameReset: handleGameReset,
    };

    // Determine game type based on category or game type
    const categorySlug = typedGame.category?.slug || "";
    const gameType = typedGame.gameType || "";

    if (categorySlug === "mathematics" || gameType === "math") {
      return <MathGame {...gameProps} />;
    } else if (categorySlug === "science" || gameType === "science") {
      return <ScienceGame {...gameProps} />;
    } else if (categorySlug === "languages" || gameType === "language") {
      return <LanguageGame {...gameProps} />;
    } else {
      // Default to trivia for general knowledge and other categories
      return <TriviaGame {...gameProps} />;
    }
  };

  if (gameLoading || questionsLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-16 min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  if (!game) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-16 min-h-screen flex items-center justify-center">
          <Card className="max-w-md">
            <CardContent className="pt-6 text-center">
              <h2 className="text-2xl font-bold text-foreground mb-4">Game Not Found</h2>
              <p className="text-muted-foreground mb-6">
                The game you're looking for doesn't exist or has been removed.
              </p>
              <Button asChild data-testid="button-back-to-games">
                <Link href="/games">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Games
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-16">
        {!isPlaying ? (
          // Game Setup Screen
          <section className="py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              {/* Back Button */}
              <div className="mb-6">
                <Button variant="ghost" asChild data-testid="button-back">
                  <Link href="/games">
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back to Games
                  </Link>
                </Button>
              </div>

              {/* Game Info */}
              <Card className="mb-8">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center space-x-3 mb-2">
                        <Badge 
                          className={getCategoryClass((game as Game).category?.name || "")}
                          data-testid="badge-game-category"
                        >
                          {(game as Game).category?.name || "General"}
                        </Badge>
                        <Badge variant="outline" data-testid="badge-game-difficulty">
                          {(game as Game).difficulty || "Beginner"}
                        </Badge>
                      </div>
                      <CardTitle className="text-3xl" data-testid="text-game-title">
                        {(game as Game).title}
                      </CardTitle>
                      {(game as Game).description && (
                        <p className="text-muted-foreground mt-2" data-testid="text-game-description">
                          {(game as Game).description}
                        </p>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                        <Target className="text-primary" size={20} />
                      </div>
                      <div>
                        <div className="font-medium">Questions</div>
                        <div className="text-sm text-muted-foreground" data-testid="text-questions-count">
                          {(questions as GameQuestion[])?.length || 0} available
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                        <Clock className="text-blue-600" size={20} />
                      </div>
                      <div>
                        <div className="font-medium">Duration</div>
                        <div className="text-sm text-muted-foreground" data-testid="text-game-duration">
                          {(game as Game).estimatedDuration || 15} minutes
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                        <Trophy className="text-green-600" size={20} />
                      </div>
                      <div>
                        <div className="font-medium">Min Age</div>
                        <div className="text-sm text-muted-foreground" data-testid="text-game-min-age">
                          {(game as Game).minAge || 5}+ years
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Game Mode Selection */}
              <Card className="mb-8">
                <CardHeader>
                  <CardTitle>Choose Game Mode</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium text-foreground mb-2 block">
                        Game Format
                      </label>
                      <Select value={gameMode} onValueChange={(value: "quiz" | "qcm" | "qro") => setGameMode(value)}>
                        <SelectTrigger className="w-full" data-testid="select-game-mode">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="quiz">Interactive Quiz</SelectItem>
                          <SelectItem value="qcm">Multiple Choice (QCM)</SelectItem>
                          <SelectItem value="qro">Open Response (QRO)</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div className="bg-muted/50 p-4 rounded-lg">
                      <h4 className="font-medium mb-2">Game Mode Information</h4>
                      {gameMode === "quiz" && (
                        <p className="text-sm text-muted-foreground">
                          Interactive quiz with immediate feedback and hints.
                        </p>
                      )}
                      {gameMode === "qcm" && (
                        <p className="text-sm text-muted-foreground">
                          Multiple choice questions with 4 possible answers.
                        </p>
                      )}
                      {gameMode === "qro" && (
                        <p className="text-sm text-muted-foreground">
                          Open response questions where you type your answer.
                        </p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Start Game */}
              <div className="text-center">
                <Button 
                  size="lg" 
                  onClick={handleGameStart}
                  className="px-8 py-4 text-lg"
                  data-testid="button-start-game"
                >
                  <Play className="w-5 h-5 mr-2" />
                  Start Game
                </Button>
              </div>
            </div>
          </section>
        ) : (
          // Game Play Screen
          <section className="py-6">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
              {/* Game Header */}
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center space-x-4">
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleGameReset}
                    data-testid="button-exit-game"
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Exit Game
                  </Button>
                  <div>
                    <h1 className="text-xl font-semibold" data-testid="text-playing-game-title">
                      {(game as Game).title}
                    </h1>
                    <p className="text-sm text-muted-foreground">
                      {gameMode.toUpperCase()} Mode
                    </p>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  size="sm" 
                  onClick={handleGameReset}
                  data-testid="button-restart-game"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Restart
                </Button>
              </div>

              {/* Game Component */}
              {renderGameComponent()}
            </div>
          </section>
        )}
      </div>

      <Footer />
    </div>
  );
}
