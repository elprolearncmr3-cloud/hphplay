import { Button } from "@/components/ui/button";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Brain, Users, TrendingUp, Smartphone, Award, Clock } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <Navigation showSearch={false} />
      
      {/* Hero Section */}
      <section className="gradient-bg py-20 pt-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-5xl md:text-6xl font-bold text-white mb-6 animate-fade-in" data-testid="text-hero-title">
              Learn Through Play
            </h1>
            <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto animate-slide-up" data-testid="text-hero-description">
              Discover thousands of educational games designed to make learning fun. From mathematics to science, languages to entrepreneurship - master any subject while having a blast!
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
              <Button asChild className="bg-white text-primary px-8 py-4 rounded-lg font-semibold hover:bg-white/90 transition-all transform hover:scale-105" data-testid="button-start-playing">
                <a href="/api/login">Start Playing Now</a>
              </Button>
              <Button variant="ghost" className="glass-effect text-white px-8 py-4 rounded-lg font-semibold hover:bg-white/20 transition-all" data-testid="button-view-demo">
                View Demo
              </Button>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 mt-16">
              <div className="text-center">
                <div className="text-3xl font-bold text-white" data-testid="text-stat-games">150+</div>
                <div className="text-white/80">Educational Games</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white" data-testid="text-stat-users">50K+</div>
                <div className="text-white/80">Active Students</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white" data-testid="text-stat-lessons">1M+</div>
                <div className="text-white/80">Lessons Completed</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-white" data-testid="text-stat-subjects">15</div>
                <div className="text-white/80">Subject Areas</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-foreground mb-4" data-testid="text-features-title">
              Why Choose HPHPlay?
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="text-features-description">
              Discover the features that make learning fun and effective for students of all ages
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center p-6" data-testid="feature-adaptive-learning">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <Brain className="text-primary" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Adaptive Learning</h3>
              <p className="text-muted-foreground">Games adapt to your skill level, ensuring optimal challenge and progress tracking</p>
            </div>

            <div className="text-center p-6" data-testid="feature-multiplayer">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="text-green-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Multiplayer Challenges</h3>
              <p className="text-muted-foreground">Compete with friends and students worldwide in educational tournaments</p>
            </div>

            <div className="text-center p-6" data-testid="feature-progress-tracking">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="text-blue-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Progress Tracking</h3>
              <p className="text-muted-foreground">Detailed analytics help you understand your learning journey and achievements</p>
            </div>

            <div className="text-center p-6" data-testid="feature-cross-platform">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Smartphone className="text-purple-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Cross-Platform</h3>
              <p className="text-muted-foreground">Play on any device - desktop, tablet, or mobile with seamless synchronization</p>
            </div>

            <div className="text-center p-6" data-testid="feature-achievements">
              <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Award className="text-orange-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Achievements & Badges</h3>
              <p className="text-muted-foreground">Earn recognition for your accomplishments with our comprehensive reward system</p>
            </div>

            <div className="text-center p-6" data-testid="feature-offline-mode">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="text-red-600" size={32} />
              </div>
              <h3 className="text-xl font-semibold text-foreground mb-3">Offline Mode</h3>
              <p className="text-muted-foreground">Continue learning even without internet connection with our offline game cache</p>
            </div>
          </div>

          {/* CTA Section */}
          <div className="text-center mt-16">
            <h3 className="text-2xl font-bold text-foreground mb-4">Ready to Start Learning?</h3>
            <p className="text-muted-foreground mb-8 max-w-2xl mx-auto">
              Join thousands of students already improving their skills through play. It's free to get started!
            </p>
            <Button asChild className="btn-primary text-lg px-8 py-3" data-testid="button-get-started">
              <a href="/api/login">Get Started for Free</a>
            </Button>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
