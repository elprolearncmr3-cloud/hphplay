import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import GameCard from "@/components/game-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { Trophy, Clock, Target, TrendingUp } from "lucide-react";
import { Game, UserStats } from "@/types/game";

export default function Home() {
  const { toast } = useToast();

  const { data: games, isLoading: gamesLoading, error: gamesError } = useQuery({
    queryKey: ["/api/games"],
    retry: false,
  });

  const { data: userStats, isLoading: statsLoading } = useQuery({
    queryKey: ["/api/user/stats"],
    retry: false,
  });

  useEffect(() => {
    if (gamesError && isUnauthorizedError(gamesError as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [gamesError, toast]);

  if (gamesLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-16 min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  const featuredGames = (games as Game[])?.slice(0, 6) || [];

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-16">
        {/* Hero Section */}
        <section className="gradient-bg py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-6" data-testid="text-welcome-title">
                Welcome Back to HPHPlay!
              </h1>
              <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto" data-testid="text-welcome-description">
                Continue your learning journey with new games and challenges. Track your progress and compete with friends!
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button asChild className="bg-white text-primary px-6 py-3 rounded-lg font-semibold hover:bg-white/90" data-testid="button-continue-learning">
                  <Link href="/games">Continue Learning</Link>
                </Button>
                <Button asChild variant="ghost" className="glass-effect text-white px-6 py-3 rounded-lg font-semibold hover:bg-white/20" data-testid="button-view-dashboard">
                  <Link href="/dashboard">View Dashboard</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>

        {/* Quick Stats */}
        {userStats && !statsLoading && (
          <section className="py-12 bg-muted/30">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <h2 className="text-2xl font-bold text-foreground mb-8 text-center" data-testid="text-quick-stats-title">
                Your Quick Stats
              </h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Trophy className="text-primary" size={24} />
                    </div>
                    <div className="text-2xl font-bold text-foreground" data-testid="text-user-games-completed">
                      {(userStats as UserStats).gamesCompleted}
                    </div>
                    <div className="text-sm text-muted-foreground">Games Completed</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Target className="text-green-600" size={24} />
                    </div>
                    <div className="text-2xl font-bold text-foreground" data-testid="text-user-total-score">
                      {(userStats as UserStats).totalScore.toLocaleString()}
                    </div>
                    <div className="text-sm text-muted-foreground">Total Score</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <Clock className="text-blue-600" size={24} />
                    </div>
                    <div className="text-2xl font-bold text-foreground" data-testid="text-user-hours-played">
                      {(userStats as UserStats).hoursPlayed}h
                    </div>
                    <div className="text-sm text-muted-foreground">Hours Played</div>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-4 text-center">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-2">
                      <TrendingUp className="text-orange-600" size={24} />
                    </div>
                    <div className="text-2xl font-bold text-foreground" data-testid="text-user-streak">
                      {(userStats as UserStats).streak}
                    </div>
                    <div className="text-sm text-muted-foreground">Day Streak</div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </section>
        )}

        {/* Featured Games */}
        <section className="py-20 bg-background">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-12">
              <div>
                <h2 className="text-3xl font-bold text-foreground mb-2" data-testid="text-featured-games-title">
                  Featured Games
                </h2>
                <p className="text-muted-foreground">
                  Popular educational games to boost your learning
                </p>
              </div>
              <Button asChild variant="outline" data-testid="button-view-all-games">
                <Link href="/games">View All Games</Link>
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredGames.map((game: Game, index: number) => (
                <GameCard 
                  key={game.id} 
                  game={game} 
                  playerCount={Math.floor(Math.random() * 5000) + 500}
                  rating={4.5 + Math.random() * 0.4}
                />
              ))}
            </div>

            {featuredGames.length === 0 && (
              <div className="text-center py-12">
                <p className="text-muted-foreground text-lg" data-testid="text-no-games-available">
                  No games available at the moment. Check back later!
                </p>
              </div>
            )}
          </div>
        </section>

        {/* Quick Actions */}
        <section className="py-20 bg-muted/30">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-3xl font-bold text-foreground mb-12 text-center" data-testid="text-quick-actions-title">
              Quick Actions
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              <Card className="hover:shadow-lg transition-shadow cursor-pointer" data-testid="card-browse-games">
                <Link href="/games">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Trophy className="text-primary" size={32} />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Browse Games</h3>
                    <p className="text-muted-foreground">Explore our collection of educational games</p>
                  </CardContent>
                </Link>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer" data-testid="card-view-progress">
                <Link href="/dashboard">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <TrendingUp className="text-green-600" size={32} />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">View Progress</h3>
                    <p className="text-muted-foreground">Track your learning achievements and stats</p>
                  </CardContent>
                </Link>
              </Card>

              <Card className="hover:shadow-lg transition-shadow cursor-pointer" data-testid="card-leaderboard">
                <Link href="/leaderboard">
                  <CardContent className="p-6 text-center">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Trophy className="text-blue-600" size={32} />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">Leaderboard</h3>
                    <p className="text-muted-foreground">See how you rank against other players</p>
                  </CardContent>
                </Link>
              </Card>
            </div>
          </div>
        </section>
      </div>

      <Footer />
    </div>
  );
}
