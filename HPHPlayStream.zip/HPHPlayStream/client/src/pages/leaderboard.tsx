import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Trophy, Medal, Award } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { LeaderboardEntry, UserStats, User } from "@/types/game";

export default function Leaderboard() {
  const { toast } = useToast();
  const { user } = useAuth();

  const { data: leaderboard, isLoading, error } = useQuery({
    queryKey: ["/api/leaderboard"],
    retry: false,
  });

  const { data: userStats } = useQuery({
    queryKey: ["/api/user/stats"],
    retry: false,
  });

  useEffect(() => {
    if (error && isUnauthorizedError(error as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [error, toast]);

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-16 min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  const getInitials = (firstName: string | null, lastName: string | null, email: string | null) => {
    if (firstName && lastName) {
      return `${firstName[0]}${lastName[0]}`.toUpperCase();
    }
    return email?.[0]?.toUpperCase() || "U";
  };

  const getDisplayName = (firstName: string | null, lastName: string | null, email: string | null) => {
    if (firstName && lastName) {
      return `${firstName} ${lastName}`;
    }
    return email || "Anonymous User";
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Trophy className="w-6 h-6 text-yellow-500" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Award className="w-6 h-6 text-orange-600" />;
      default:
        return (
          <div className="w-6 h-6 bg-muted rounded-full flex items-center justify-center text-muted-foreground text-sm font-bold">
            {rank}
          </div>
        );
    }
  };

  const getRankBadgeColor = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case 2:
        return "bg-gray-100 text-gray-800 border-gray-200";
      case 3:
        return "bg-orange-100 text-orange-800 border-orange-200";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const currentUserRank = (leaderboard as LeaderboardEntry[])?.findIndex((entry: LeaderboardEntry) => entry.user.id === (user as User)?.id) + 1;

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-16">
        {/* Header */}
        <section className="bg-muted/30 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-foreground mb-4" data-testid="text-leaderboard-title">
                Global Leaderboard
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="text-leaderboard-description">
                See how you stack up against players from around the world
              </p>
            </div>
          </div>
        </section>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          {/* User's Current Position */}
          {userStats && currentUserRank && (
            <Card className="mb-8 border-primary/20 bg-primary/5">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <Badge className={getRankBadgeColor(currentUserRank)} data-testid="badge-user-rank">
                      #{currentUserRank}
                    </Badge>
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={(user as User)?.profileImageUrl || ""} alt="Your avatar" />
                      <AvatarFallback className="bg-primary text-primary-foreground">
                        {getInitials((user as User)?.firstName, (user as User)?.lastName, (user as User)?.email)}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <div className="font-semibold text-foreground" data-testid="text-user-position">
                        Your Position
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {getDisplayName((user as User)?.firstName, (user as User)?.lastName, (user as User)?.email)}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-primary" data-testid="text-user-leaderboard-score">
                      {(userStats as UserStats).totalScore.toLocaleString()} pts
                    </div>
                    <div className="text-sm text-muted-foreground">
                      {(userStats as UserStats).gamesCompleted} games completed
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Top Players */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Trophy className="w-6 h-6 text-primary" />
                <span data-testid="text-top-players-title">Top Players This Week</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {leaderboard && (leaderboard as LeaderboardEntry[]).length > 0 ? (
                <div className="space-y-4">
                  {(leaderboard as LeaderboardEntry[]).map((entry: LeaderboardEntry, index: number) => {
                    const isCurrentUser = entry.user.id === (user as User)?.id;
                    
                    return (
                      <div
                        key={entry.user.id}
                        className={`flex items-center justify-between p-4 rounded-lg transition-colors ${
                          isCurrentUser 
                            ? "bg-primary/10 border border-primary/20" 
                            : "hover:bg-muted/50"
                        }`}
                        data-testid={`row-leaderboard-${entry.rank}`}
                      >
                        <div className="flex items-center space-x-4">
                          {getRankIcon(entry.rank)}
                          
                          <Avatar className="w-10 h-10">
                            <AvatarImage 
                              src={entry.user.profileImageUrl || ""} 
                              alt={getDisplayName(entry.user.firstName, entry.user.lastName, entry.user.email)}
                            />
                            <AvatarFallback className="bg-primary text-primary-foreground text-sm">
                              {getInitials(entry.user.firstName, entry.user.lastName, entry.user.email)}
                            </AvatarFallback>
                          </Avatar>
                          
                          <div>
                            <div className={`font-medium ${isCurrentUser ? "text-primary" : "text-foreground"}`} data-testid={`text-player-name-${entry.rank}`}>
                              {getDisplayName(entry.user.firstName, entry.user.lastName, entry.user.email)}
                              {isCurrentUser && (
                                <Badge variant="secondary" className="ml-2 text-xs">You</Badge>
                              )}
                            </div>
                            <div className="text-sm text-muted-foreground">
                              Rank #{entry.rank}
                            </div>
                          </div>
                        </div>
                        
                        <div className="text-right">
                          <div className={`font-semibold ${isCurrentUser ? "text-primary" : "text-foreground"}`} data-testid={`text-player-score-${entry.rank}`}>
                            {entry.totalScore.toLocaleString()} pts
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Total Score
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <Trophy className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-foreground mb-2" data-testid="text-no-leaderboard-title">
                    No Rankings Yet
                  </h3>
                  <p className="text-muted-foreground" data-testid="text-no-leaderboard-message">
                    Be the first to play games and appear on the leaderboard!
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* How Rankings Work */}
          <Card className="mt-8">
            <CardHeader>
              <CardTitle data-testid="text-ranking-info-title">How Rankings Work</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm text-muted-foreground">
              <p>• Rankings are based on your total score across all games</p>
              <p>• Your position updates in real-time as you play and improve</p>
              <p>• Play more games and achieve higher scores to climb the leaderboard</p>
              <p>• Rankings reset weekly to give everyone a fresh start</p>
            </CardContent>
          </Card>
        </div>
      </div>

      <Footer />
    </div>
  );
}
