import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import GameCard from "@/components/game-card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Search, Filter } from "lucide-react";
import { Game, GameCategory } from "@/types/game";

export default function Games() {
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState<number | null>(null);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: games, isLoading: gamesLoading, error: gamesError } = useQuery({
    queryKey: selectedCategory ? ["/api/games", `?category=${selectedCategory}`] : ["/api/games"],
    retry: false,
  });

  const { data: categories, isLoading: categoriesLoading } = useQuery({
    queryKey: ["/api/categories"],
    retry: false,
  });

  useEffect(() => {
    if (gamesError && isUnauthorizedError(gamesError as Error)) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [gamesError, toast]);

  const filteredGames = (games as Game[])?.filter((game: Game) => {
    if (searchQuery) {
      return game.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
             game.description?.toLowerCase().includes(searchQuery.toLowerCase()) ||
             game.category?.name.toLowerCase().includes(searchQuery.toLowerCase());
    }
    return true;
  }) || [];

  const handleCategoryFilter = (categoryId: number | null) => {
    setSelectedCategory(categoryId);
  };

  if (gamesLoading || categoriesLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-16 min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-16">
        {/* Header Section */}
        <section className="bg-muted/30 py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-foreground mb-4" data-testid="text-games-title">
                Educational Games
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="text-games-description">
                Choose from our diverse collection of educational games tailored to different subjects and skill levels
              </p>
            </div>

            {/* Search Bar */}
            <div className="max-w-md mx-auto">
              <div className="relative">
                <Input
                  type="search"
                  placeholder="Search games..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-3 text-base"
                  data-testid="input-search-games-page"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground" size={20} />
              </div>
            </div>
          </div>
        </section>

        {/* Category Filters */}
        <section className="py-8 bg-background border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex flex-wrap justify-center gap-4">
              <Button
                variant={selectedCategory === null ? "default" : "outline"}
                onClick={() => handleCategoryFilter(null)}
                className="px-6 py-3"
                data-testid="button-filter-all"
              >
                All Games
              </Button>
              {(categories as GameCategory[])?.map((category: GameCategory) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  onClick={() => handleCategoryFilter(category.id)}
                  className="px-6 py-3"
                  data-testid={`button-filter-${category.slug}`}
                >
                  {category.name}
                </Button>
              ))}
            </div>
          </div>
        </section>

        {/* Games Grid */}
        <section className="py-16">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {filteredGames.length > 0 ? (
              <>
                <div className="flex items-center justify-between mb-8">
                  <div>
                    <h2 className="text-2xl font-semibold text-foreground" data-testid="text-games-count">
                      {filteredGames.length} Games Found
                    </h2>
                    {selectedCategory && (
                      <p className="text-muted-foreground">
                        Showing games in{" "}
                        <Badge variant="secondary" data-testid="badge-selected-category">
                          {(categories as GameCategory[])?.find((c: GameCategory) => c.id === selectedCategory)?.name}
                        </Badge>
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredGames.map((game: Game) => (
                    <GameCard 
                      key={game.id} 
                      game={game} 
                      playerCount={Math.floor(Math.random() * 5000) + 100}
                      rating={4.0 + Math.random() * 1.0}
                    />
                  ))}
                </div>
              </>
            ) : (
              <Card className="max-w-2xl mx-auto">
                <CardContent className="py-16 text-center">
                  <Filter className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-xl font-semibold text-foreground mb-2" data-testid="text-no-games-title">
                    No Games Found
                  </h3>
                  <p className="text-muted-foreground mb-6" data-testid="text-no-games-message">
                    {searchQuery 
                      ? `No games match your search "${searchQuery}"`
                      : selectedCategory 
                        ? "No games available in this category" 
                        : "No games available at the moment"
                    }
                  </p>
                  {(searchQuery || selectedCategory) && (
                    <Button 
                      onClick={() => {
                        setSearchQuery("");
                        setSelectedCategory(null);
                      }}
                      data-testid="button-clear-filters"
                    >
                      Clear Filters
                    </Button>
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </section>
      </div>

      <Footer />
    </div>
  );
}
