import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navigation from "@/components/navigation";
import Footer from "@/components/footer";
import ProgressBar from "@/components/progress-bar";
import AchievementBadge from "@/components/achievement-badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trophy, Target, Clock, TrendingUp, Star, Calculator, FlaskConical, Book } from "lucide-react";
import { UserGameProgress, UserAchievement, UserStats } from "@/types/game";

export default function Dashboard() {
  const { toast } = useToast();

  const { data: userStats, isLoading: statsLoading, error: statsError } = useQuery({
    queryKey: ["/api/user/stats"],
    retry: false,
  });

  const { data: userProgress, isLoading: progressLoading, error: progressError } = useQuery({
    queryKey: ["/api/user/progress"],
    retry: false,
  });

  const { data: userAchievements, isLoading: achievementsLoading, error: achievementsError } = useQuery({
    queryKey: ["/api/user/achievements"],
    retry: false,
  });

  useEffect(() => {
    const errors = [statsError, progressError, achievementsError].filter(Boolean);
    const unauthorizedError = errors.find(error => isUnauthorizedError(error as Error));
    
    if (unauthorizedError) {
      toast({
        title: "Unauthorized",
        description: "You are logged out. Logging in again...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [statsError, progressError, achievementsError, toast]);

  if (statsLoading || progressLoading || achievementsLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navigation />
        <div className="pt-16 min-h-screen flex items-center justify-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
        </div>
      </div>
    );
  }

  const getCategoryIcon = (categoryName: string) => {
    switch (categoryName.toLowerCase()) {
      case "mathematics":
        return Calculator;
      case "science":
        return FlaskConical;
      case "languages":
        return Book;
      default:
        return Star;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      
      <div className="pt-16">
        {/* Header */}
        <section className="bg-muted/30 py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-foreground mb-4" data-testid="text-dashboard-title">
                Your Learning Dashboard
              </h1>
              <p className="text-xl text-muted-foreground max-w-2xl mx-auto" data-testid="text-dashboard-description">
                Track your progress, view achievements, and see how you stack up against other players
              </p>
            </div>
          </div>
        </section>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Stats Overview */}
            <div className="lg:col-span-2 space-y-6">
              {/* Performance Overview */}
              <Card>
                <CardHeader>
                  <CardTitle data-testid="text-performance-overview-title">Performance Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  {userStats ? (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                      <div className="text-center">
                        <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-3">
                          <Trophy className="text-primary" size={24} />
                        </div>
                        <div className="text-2xl font-bold text-foreground" data-testid="text-stats-games-completed">
                          {(userStats as UserStats).gamesCompleted}
                        </div>
                        <div className="text-sm text-muted-foreground">Games Completed</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-3">
                          <Target className="text-green-600" size={24} />
                        </div>
                        <div className="text-2xl font-bold text-foreground" data-testid="text-stats-total-score">
                          {(userStats as UserStats).totalScore.toLocaleString()}
                        </div>
                        <div className="text-sm text-muted-foreground">Total Score</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-3">
                          <Clock className="text-blue-600" size={24} />
                        </div>
                        <div className="text-2xl font-bold text-foreground" data-testid="text-stats-hours-played">
                          {(userStats as UserStats).hoursPlayed}h
                        </div>
                        <div className="text-sm text-muted-foreground">Hours Played</div>
                      </div>
                      
                      <div className="text-center">
                        <div className="w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center mx-auto mb-3">
                          <TrendingUp className="text-orange-600" size={24} />
                        </div>
                        <div className="text-2xl font-bold text-foreground" data-testid="text-stats-streak">
                          {(userStats as UserStats).streak}
                        </div>
                        <div className="text-sm text-muted-foreground">Day Streak</div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground" data-testid="text-no-stats">
                        No statistics available yet. Start playing games to see your progress!
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Subject Progress */}
              <Card>
                <CardHeader>
                  <CardTitle data-testid="text-subject-progress-title">Subject Progress</CardTitle>
                </CardHeader>
                <CardContent>
                  {userProgress && (userProgress as UserGameProgress[]).length > 0 ? (
                    <div className="space-y-6">
                      {(userProgress as (UserGameProgress & { game?: { title: string; category?: { name: string } } })[]).map((progress) => {
                        const categoryName = progress.game?.category?.name || "General";
                        const Icon = getCategoryIcon(categoryName);
                        const completionRate = parseFloat(progress.completionRate || "0");
                        
                        return (
                          <div key={progress.id} className="space-y-2">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center space-x-3">
                                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
                                  <Icon className="text-primary" size={20} />
                                </div>
                                <div>
                                  <div className="font-medium text-foreground" data-testid={`text-progress-game-${progress.id}`}>
                                    {progress.game?.title || "Unknown Game"}
                                  </div>
                                  <div className="text-sm text-muted-foreground">
                                    {completionRate.toFixed(0)}% complete
                                  </div>
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="text-sm font-medium text-foreground" data-testid={`text-progress-score-${progress.id}`}>
                                  {progress.totalScore?.toLocaleString()} pts
                                </div>
                                <div className="text-xs text-muted-foreground">
                                  Played {progress.timesPlayed} times
                                </div>
                              </div>
                            </div>
                            <ProgressBar value={completionRate} />
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <p className="text-muted-foreground" data-testid="text-no-progress">
                        No progress data available yet. Start playing games to track your progress!
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>

            {/* Achievements & Recent Activity */}
            <div className="space-y-6">
              {/* Recent Achievements */}
              <Card>
                <CardHeader>
                  <CardTitle data-testid="text-achievements-title">Recent Achievements</CardTitle>
                </CardHeader>
                <CardContent>
                  {userAchievements && (userAchievements as UserAchievement[]).length > 0 ? (
                    <div className="space-y-4">
                      {(userAchievements as UserAchievement[]).slice(0, 5).map((userAchievement: UserAchievement) => (
                        <AchievementBadge 
                          key={userAchievement.id}
                          achievement={userAchievement.achievement}
                          size="sm"
                        />
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Trophy className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                      <p className="text-muted-foreground" data-testid="text-no-achievements">
                        No achievements unlocked yet. Keep playing to earn your first badge!
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <a 
                    href="/games" 
                    className="block w-full text-left px-3 py-2 rounded-md hover:bg-muted transition-colors"
                    data-testid="link-browse-games"
                  >
                    <div className="font-medium">Browse Games</div>
                    <div className="text-sm text-muted-foreground">Discover new educational games</div>
                  </a>
                  
                  <a 
                    href="/leaderboard" 
                    className="block w-full text-left px-3 py-2 rounded-md hover:bg-muted transition-colors"
                    data-testid="link-view-leaderboard"
                  >
                    <div className="font-medium">View Leaderboard</div>
                    <div className="text-sm text-muted-foreground">See how you rank globally</div>
                  </a>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
}
